freeglut 2.4.0-2.mp for MinGW

This package contains freeglut import libraries, headers, and a Windows DLL,
allowing GLUT applications to be compiled on Windows using MinGW. Both static
and shared versions of the library are included.

For more information on freeglut, visit http://freeglut.sourceforge.net/.


Installation

Copy the files from the �lib/� directory of this package to the �lib/� folder of
your MinGW installation. The files from the �include/� folder should be copied
to the �include/� folder of your MinGW installation (be careful if you have
another GLUT installation, as it will likely also have placed a �glut.h� in this
folder�you should back up the original rather than overwrite it). The freeglut
DLL should either be placed in the same directory as your application, or can be
installed system wide in a folder such as �C:\Windows\System32\� on a typical
Windows machine. Don�t forget to redistribute the DLL with your applications if
you are using dynamic linking!


Compiling Applications

If you want your application to be compatible with GLUT, you should
�#include <GL/glut.h>�. If you want to use freeglut specific extensions, you
should �#include <GL/freeglut.h>� instead.

Given a source file �test.c�, which you want to compile to an application
�test.exe� dynamically linking to the DLL, you can use the following command
line:

  gcc -o test.exe test.c -lfreeglut -lopengl32 -Wl,--subsystem,windows

To statically link to the freeglut library, you should use this command line
instead (note the different linker flag, and the macro definition):

  gcc -o test.exe test.c -D FREEGLUT_STATIC -lfreeglut_static -lopengl32 ^
      -lwinmm -lgdi32 -Wl,--subsystem,windows

The �-Wl,--subsystem,windows� is needed so that the application compiles as a
Windows GUI application rather than a console application. If you are using GLU
functions you should also include �-lglu32� on the command line.

Please visit http://www.transmissionzero.co.uk/computing/using-glut-with-mingw/
for further information and usage.


Changelog

2009�09�05: Release 2.4.0-2.mp

  � Added a version information resource to the DLL, so that the version and
    copyright info can be viewed using Windows Explorer (typically obtained by
    right clicking the DLL in Windows Explorer, going to �Properties�, then
    going to �Details�).
  � Changed the DLL and import library so that they export / import undecorated
    functions, i.e. �glutMainLoop� instead of �glutMainLoop@0�. This provides
    binary compatibility with my Microsoft Visual C++ freeglut package, and
    gives better binary compatibility with GLUT for Win32 applications built
    without the �atexit� hack. The DLL additionally exports decorated functions,
    to ensure backward compatibility with the previous version. I would
    encourage you to re-link existing applications against the new import
    library.

2009�04�11: Release 2.4.0-1.mp

  � First build using MinGW. I�ve created a Windows DLL with an import library,
    as well as a library for statically linking against freeglut.


Martin Payne
2009�09�05

http://www.transmissionzero.co.uk/
